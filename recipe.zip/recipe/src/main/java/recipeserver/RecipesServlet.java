package recipeserver;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.util.*;

@WebServlet(urlPatterns = {"/api/recipes/*"}) 
public class RecipesServlet extends HttpServlet {

    public static Connection getConnection() throws SQLException {
        // Class.forName("com.mysql.cj.jdbc.Driver");
        String url = "jdbc:mysql://localhost:3306/recipesdb";
        String user = "root";
        String pass = "";
        
        System.out.println("trying to connect " + url);
        Connection conn = DriverManager.getConnection(url, user, pass);
        System.out.println("db con success");
        return conn;
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        String pathInfo = req.getPathInfo();

        if (pathInfo == null || pathInfo.equals("/")) {
            getAllRecipes(req, resp);
        } else if (pathInfo.equals("/search")) {
            searchRecipes(req, resp);
        }
    }
    
    private void searchRecipes(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        String cal = "";
        String title1 = "";
        String cuisine1 = "";
        String totaltime = "";
        String rating1 = "";

        try {
            String caloriesParam = req.getParameter("calories");
            if (caloriesParam != null && !caloriesParam.isEmpty()) {
                cal = caloriesParam;
            }
            
            String titleParam = req.getParameter("title");
            if (titleParam != null && !titleParam.isEmpty()) {
                title1 = titleParam;
            }
            
            String cuisineParam = req.getParameter("cuisine");
            if (cuisineParam != null && !cuisineParam.isEmpty()) {
                cuisine1 = cuisineParam;
            }
            
            String totalTimeParam = req.getParameter("total_time");
            if (totalTimeParam != null && !totalTimeParam.isEmpty()) {
                totaltime = totalTimeParam;
            }
            
            String ratingParam = req.getParameter("rating");
            if (ratingParam != null && !ratingParam.isEmpty()) {
            	System.out.print(ratingParam);
                rating1 = ratingParam;
            }
        } catch (NumberFormatException e) {
            resp.getWriter().print("Invalid number format for a parameter.");
            return;
        }

        String baseSql = "SELECT * FROM recipes";
        List<String> conditions = new ArrayList<>();
        List<Object> params = new ArrayList<>();

        if (!cal.isEmpty()) {
            conditions.add("CAST( SUBSTRING_INDEX( JSON_UNQUOTE( JSON_EXTRACT(nutrients, '$.calories') ), ' ', 1) AS UNSIGNED) "+cal);
//            params.add(cal);
        }
        if (!title1.isEmpty()) {
            conditions.add("title LIKE ?");
            params.add("%" + title1 + "%");
        }
        if (!cuisine1.isEmpty()) {
            conditions.add("cuisine = ?");
            params.add(cuisine1);
        }
        if (!totaltime.isEmpty()) {
            conditions.add("total_time "+totaltime);
//            params.add(totaltime);
        }
        if (!rating1.isEmpty()) {
            conditions.add("rating "+rating1);
//            params.add(rating1);
        }

        String finalSql = baseSql;
        if (!conditions.isEmpty()) {
            finalSql += " WHERE " + String.join(" AND ", conditions);
        }

        JSONArray resultsArray = new JSONArray();
        JSONParser parser = new JSONParser();

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(finalSql);
             PrintWriter out = resp.getWriter()) {

            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }
            
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                JSONObject recipeObj = new JSONObject();
                recipeObj.put("id", rs.getInt("id"));
                recipeObj.put("cuisine", rs.getString("cuisine"));
                recipeObj.put("title", rs.getString("title"));
                recipeObj.put("rating", rs.getObject("rating"));
                recipeObj.put("prep_time", rs.getObject("prep_time"));
                recipeObj.put("cook_time", rs.getObject("cook_time"));
                recipeObj.put("total_time", rs.getObject("total_time"));
                recipeObj.put("description", rs.getString("description"));
                String nutrientsStr = rs.getString("nutrients");
                if (nutrientsStr != null && !nutrientsStr.isEmpty()) {
                    recipeObj.put("nutrients", parser.parse(nutrientsStr));
                } else {
                    recipeObj.put("nutrients", null);
                }
                recipeObj.put("serves", rs.getString("serves"));
                resultsArray.add(recipeObj);
            }

            out.print(resultsArray.toJSONString());

        } catch (SQLException | ParseException e) {
            e.printStackTrace();
        }
    }
   
    private void getAllRecipes(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("get request");
        resp.setContentType("application/json;charset=UTF-8");

        int page = 1;
        int limit = 10;

        String pageParam = req.getParameter("page");
        if (pageParam != null && !pageParam.isEmpty()) {
            page = Integer.parseInt(pageParam);
        }
        String limitParam = req.getParameter("limit");
        if (limitParam != null && !limitParam.isEmpty()) {
            limit = Integer.parseInt(limitParam);
        }

        int offset = (page - 1) * limit;

        JSONObject responseObj = new JSONObject();
        JSONArray dataArray = new JSONArray();
        long totalRecipes = 0;

        JSONParser parser = new JSONParser();

        try (PrintWriter out = resp.getWriter(); Connection conn = getConnection()) {

            String countSql = "SELECT COUNT(*) AS total FROM recipes";
            try (Statement countStmt = conn.createStatement(); ResultSet countRs = countStmt.executeQuery(countSql)) {
                if (countRs.next()) {
                    totalRecipes = countRs.getLong("total");
                }
            }

            String dataSql = "SELECT id, cuisine, title, rating, prep_time, cook_time, total_time, description, nutrients, serves FROM recipes order by rating desc LIMIT ? OFFSET ?";
            
            System.out.println("LIMIT=" + limit + ", OFFSET=" + offset);

            try (PreparedStatement dataStmt = conn.prepareStatement(dataSql)) {
                dataStmt.setInt(1, limit);
                dataStmt.setInt(2, offset);
                
                try (ResultSet rs = dataStmt.executeQuery()) {
                    while (rs.next()) {
                        JSONObject recipeObj = new JSONObject();
                        recipeObj.put("id", rs.getInt("id"));
                        recipeObj.put("cuisine", rs.getString("cuisine"));
                        recipeObj.put("title", rs.getString("title"));
                        
                        double rating = rs.getDouble("rating");
                        if (rs.wasNull()) recipeObj.put("rating", null); else recipeObj.put("rating", rating);
                        
                        Integer prep = rs.getObject("prep_time") != null ? rs.getInt("prep_time") : null;
                        recipeObj.put("prep_time", prep);
                        
                        Integer cook = rs.getObject("cook_time") != null ? rs.getInt("cook_time") : null;
                        recipeObj.put("cook_time", cook);
                        
                        Integer total = rs.getObject("total_time") != null ? rs.getInt("total_time") : null;
                        recipeObj.put("total_time", total);
                        
                        recipeObj.put("description", rs.getString("description"));

                        String nutrientsStr = rs.getString("nutrients");
                        if (nutrientsStr != null && !nutrientsStr.isEmpty()) {
                            try {
                                recipeObj.put("nutrients", parser.parse(nutrientsStr));
                            } catch (ParseException e) {
                                recipeObj.put("nutrients", null);
                            }
                        } else {
                            recipeObj.put("nutrients", null);
                        }
                        
                        recipeObj.put("serves", rs.getString("serves"));
                        dataArray.add(recipeObj);
                    }
                }
            }
            
            
            responseObj.put("page", page);
            responseObj.put("limit", limit);
            responseObj.put("data", dataArray);
            responseObj.put("total", totalRecipes);
            
            out.print(responseObj.toJSONString());

        } catch (SQLException e) {
            System.err.println("error occured"+e);
            e.printStackTrace();
            
        }
    }
}