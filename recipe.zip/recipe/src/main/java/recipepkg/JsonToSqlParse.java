package recipepkg;

import java.io.*;
import java.sql.*;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
public class JsonToSqlParse {
    public static void main(String[] args) {
//    	Class.forName("com.mysql.cj.jdbc.Driver");
        String url = "jdbc:mysql://localhost:3306/recipesdb";
        String user = "root";
        String password = "";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            JSONParser parser = new JSONParser();
        JSONObject recipes = (JSONObject) parser.parse(new FileReader("/Users/rl/Workspace/securin/US_recipes_null.json"));

        String createSql = "CREATE TABLE IF NOT EXISTS recipes ("
            + "id INT AUTO_INCREMENT PRIMARY KEY,"
            + "cuisine VARCHAR(255),"
            + "title VARCHAR(255),"
            + "rating DOUBLE,"
            + "prep_time INT,"
            + "cook_time INT,"
            + "total_time INT,"
            + "description TEXT,"
            + "nutrients JSON,"
            + "serves VARCHAR(255)"
            + ")";
        conn.createStatement().executeUpdate(createSql);

        String sql = "INSERT INTO recipes (cuisine, title, rating, prep_time, cook_time, total_time, description, nutrients, serves) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);

            for (Object key : recipes.keySet()) {
                JSONObject recipe = (JSONObject) recipes.get(key);
                String cuisine = (String) recipe.get("cuisine");
                String title = (String) recipe.get("title");
                Object rating =  recipe.get("rating");
                Object prep = recipe.get("prep_time");
                Object cook = recipe.get("cook_time");
                Object total = recipe.get("total_time");
                Object nutrients = recipe.get("nutrients");
                String serves = (String) recipe.get("serves");
                stmt.setString(1,cuisine);
                stmt.setString(2, title);
                if (rating == null) {
                    stmt.setNull(3, java.sql.Types.DOUBLE);
                } else {
                    stmt.setDouble(3, Double.parseDouble(rating.toString()));
                }
                if (prep == null || cook == null) {
                    stmt.setNull(4, java.sql.Types.INTEGER);
                    stmt.setNull(5, java.sql.Types.INTEGER);
                } else {
                    stmt.setInt(4, Integer.parseInt(prep.toString()));
                    stmt.setInt(5, Integer.parseInt(cook.toString()));
                }
                if (total == null) {
                    stmt.setNull(6, java.sql.Types.INTEGER);
                } else {
                    stmt.setInt(6, Integer.parseInt(total.toString()));
                }
                stmt.setString(7, (String) recipe.get("description"));
                stmt.setString(8, nutrients != null ? nutrients.toString() : null);
                stmt.setString(9, serves);
                stmt.executeUpdate();
            }
            stmt.close();
            conn.commit();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}